package edu.unh.cs.cs518.motivate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MotivateApplication {
    public static void main(String[] args) {
        SpringApplication.run(MotivateApplication.class, args);
    }
}
