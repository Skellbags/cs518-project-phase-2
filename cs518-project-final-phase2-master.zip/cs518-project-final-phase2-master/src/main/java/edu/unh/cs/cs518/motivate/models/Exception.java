package edu.unh.cs.cs518.motivate.models;

public class Exception {
    public final String message;

    public Exception(String message) {
        this.message = message;
    }
}
