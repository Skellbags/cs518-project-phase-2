package edu.unh.cs.cs518.motivate.models;

public class InternalException extends Exception {
    public InternalException() {
        super("An internal error has occurred.");
    }
}
