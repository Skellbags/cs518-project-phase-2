Phase 2 Plan, Organized by Tasks and Assigned to Team Members

- Add Spring functionality - Ryan
- Create at least 3 unit tests - Riley
- Define Dockerfile - Riley
- Define gitlab-ci.yml - Riley
- Create Azure web app from the Docker image - Riley
- Implement website to display Spring API's capabilities - Ramya
- Delpoy frontend to Azure blob storage - Riley
